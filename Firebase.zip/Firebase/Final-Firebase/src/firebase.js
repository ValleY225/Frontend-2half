// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDKKzNyrj1GZiKrAMzM-sHq9bObYcuro4Q",
  authDomain: "fir-ecddc.firebaseapp.com",
  projectId: "fir-ecddc",
  storageBucket: "fir-ecddc.firebasestorage.app",
  messagingSenderId: "839407939957",
  appId: "1:839407939957:web:49847b5ca81c0f9079633c"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export default app;