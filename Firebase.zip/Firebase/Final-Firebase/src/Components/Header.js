// src/components/Header.js
import React, { useState } from "react";
import "../Style/Header.css";
import Modal from "./Modal";
import DeliveryForm from "./DeliveryForm";
import ReservationForm from "./ReservationForm";

import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from "firebase/auth";
import app from "../firebase";

const auth = getAuth(app);

const Header = () => {
  const [showDelivery, setShowDelivery] = useState(false);
  const [showReservation, setShowReservation] = useState(false);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [user, setUser] = useState(null);

  const handleLogin = async () => {
    try {
      const result = await signInWithEmailAndPassword(auth, email, password);
      setUser(result.user);
      alert('Logged in successfully!');
      setEmail('');
      setPassword('');
    } catch (error) {
      alert(error.message);
    }
  };

  const handleRegister = async () => {
    try {
      const result = await createUserWithEmailAndPassword(auth, email, password);
      setUser(result.user);
      alert('Registered successfully!');
      setEmail('');
      setPassword('');
    } catch (error) {
      alert(error.message);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    setUser(null);
    alert('Logged out!');
  };

  return (
    <header className="Header">
      <nav className="nav-buttons">
        <button className="primary-btn" onClick={() => setShowDelivery(true)}>
          Order Delivery
        </button>
        <button className="primary-btn" onClick={() => setShowReservation(true)}>
          Reserve Table
        </button>
      </nav>

      <div className="auth-section">
        {user ? (
          <div>
            <span className="welcome">Welcome, {user.email}</span>
            <button className="secondary-btn" onClick={handleLogout}>
              Logout
            </button>
          </div>
        ) : (
          <div className="auth-forms">
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button className="secondary-btn" onClick={handleLogin}>Login</button>
            <button className="secondary-btn" onClick={handleRegister}>Register</button>
          </div>
        )}
      </div>

      <Modal isOpen={showDelivery} onClose={() => setShowDelivery(false)}>
        <DeliveryForm onClose={() => setShowDelivery(false)} />
      </Modal>

      <Modal isOpen={showReservation} onClose={() => setShowReservation(false)}>
        <ReservationForm onClose={() => setShowReservation(false)} />
      </Modal>
    </header>
  );
};

export default Header;
