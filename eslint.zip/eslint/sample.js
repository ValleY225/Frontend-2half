function Image() {
    return <img src="/img.png" />;
    }
    