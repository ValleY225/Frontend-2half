console.log("Prettier Test");

// prettier --check "sample.js"

// prettier --write "sample.js"
