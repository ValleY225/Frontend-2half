import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import Modal from "../Components/Modal";

describe("Modal Component", () => {
  test("renders nothing when isOpen is false", () => {
    const { container } = render(
      <Modal isOpen={false} onClose={jest.fn()}>
        <div>Test Content</div>
      </Modal>
    );
    expect(container.firstChild).toBeNull();
  });

  test("renders modal content and close button when isOpen is true", () => {
    render(
      <Modal isOpen={true} onClose={jest.fn()}>
        <div data-testid="child">Test Content</div>
      </Modal>
    );
    // Check child content is rendered
    expect(screen.getByTestId("child")).toHaveTextContent("Test Content");
    // Verify the close button is rendered with the correct label
    expect(screen.getByRole("button")).toHaveTextContent("×");
  });

  test("calls onClose when the close button is clicked", () => {
    const onCloseMock = jest.fn();
    render(
      <Modal isOpen={true} onClose={onCloseMock}>
        <div>Test Content</div>
      </Modal>
    );
    fireEvent.click(screen.getByRole("button"));
    expect(onCloseMock).toHaveBeenCalledTimes(1);
  });
});
