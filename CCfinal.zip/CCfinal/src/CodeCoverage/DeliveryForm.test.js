import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import DeliveryForm from "../Components/DeliveryForm";

// Mock loadGoogleMapsScript by mocking the global window.google object
beforeAll(() => {
  global.google = {
    maps: {
      places: {
        Autocomplete: class {
          constructor() {}
          addListener() {}
          getPlace() {
            return { formatted_address: "123 Test St" };
          }
        },
      },
    },
  };
});

describe("DeliveryForm Component", () => {
  const mockOnClose = jest.fn();

  beforeEach(() => {
    render(<DeliveryForm onClose={mockOnClose} />);
  });

  test("renders input fields and buttons", () => {
    expect(screen.getByPlaceholderText(/enter your address/i)).toBeInTheDocument();
    expect(screen.getByPlaceholderText(/enter your phone number/i)).toBeInTheDocument();
    expect(screen.getByPlaceholderText(/enter information for courier/i)).toBeInTheDocument();
    expect(screen.getByText(/order/i)).toBeInTheDocument();
    expect(screen.getByText(/cancel/i)).toBeInTheDocument();
  });

  test("submits form and triggers onClose", () => {
    fireEvent.change(screen.getByPlaceholderText(/enter your address/i), {
      target: { value: "123 Main St" },
    });
    fireEvent.change(screen.getByPlaceholderText(/enter your phone number/i), {
      target: { value: "5551234567" },
    });
    fireEvent.change(screen.getByPlaceholderText(/enter information for courier/i), {
      target: { value: "Leave at the door" },
    });

    fireEvent.click(screen.getByText(/order/i));
    expect(mockOnClose).toHaveBeenCalled();
  });

  test("cancels the form", () => {
    fireEvent.click(screen.getByText(/cancel/i));
    expect(mockOnClose).toHaveBeenCalled();
  });
});
