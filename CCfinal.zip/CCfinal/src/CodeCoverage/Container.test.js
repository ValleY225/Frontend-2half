import React from "react";
import { render, screen } from "@testing-library/react";
import Container from "../Components/Container";

// Mock child components to isolate testing to the Container layout
jest.mock("../Components/Header", () => () => <div data-testid="header" />);
jest.mock("../Components/MenuGrid", () => () => <div data-testid="menugrid" />);
jest.mock("../Components/Navbar", () => () => <div data-testid="navbar" />);

describe("Container Component", () => {
  test("renders Header, MenuGrid, and Navbar components", () => {
    render(<Container />);
    expect(screen.getByTestId("header")).toBeInTheDocument();
    expect(screen.getByTestId("menugrid")).toBeInTheDocument();
    expect(screen.getByTestId("navbar")).toBeInTheDocument();
  });
});
