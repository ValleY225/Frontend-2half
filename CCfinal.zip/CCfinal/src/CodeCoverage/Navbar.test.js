import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import Navbar from "../Components/Navbar";

describe("Navbar Component", () => {
  beforeEach(() => {
    render(<Navbar />);
  });

  test("renders all nav buttons", () => {
    // Check that all expected buttons are in the document
    expect(screen.getByRole("button", { name: /pizzas/i })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /hot meals/i })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /drinks/i })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /desserts/i })).toBeInTheDocument();
  });

  test("clicking on a nav button blurs the button and scrolls to the corresponding section", () => {
    // Create a dummy section element with id "pizzas" and append to document.body
    const section = document.createElement("div");
    section.id = "pizzas";
    document.body.appendChild(section);
    // Create a spy on the section's scrollIntoView
    const scrollSpy = jest.spyOn(section, "scrollIntoView").mockImplementation(() => {});
    
    // Get the Pizza nav button
    const button = screen.getByRole("button", { name: /pizzas/i });
    // Spy on the button's blur method
    const blurSpy = jest.spyOn(button, "blur");

    // Simulate clicking the button
    fireEvent.click(button);

    expect(blurSpy).toHaveBeenCalled();
    expect(scrollSpy).toHaveBeenCalledWith({ behavior: "smooth" });

    // Clean up the dummy section
    document.body.removeChild(section);
  });

  test("does nothing if the corresponding section is not found", () => {
    // For a section that does not exist, ensure no error is thrown.
    // (Here we simulate clicking the Hot Meals button when no dummy element is provided.)

    // Get the Hot Meals button.
    const button = screen.getByRole("button", { name: /hot meals/i });
    const blurSpy = jest.spyOn(button, "blur");

    // This click should simply call blur(), and no scrollIntoView is called.
    fireEvent.click(button);

    expect(blurSpy).toHaveBeenCalled();
    // There is no section, so nothing to scroll into view.
    // Test passes if no error is thrown.
  });
});
