import menuItems from "../Components/Data.js"; 

describe("menuItems Module", () => {
  test("should export an array with 12 items", () => {
    expect(Array.isArray(menuItems)).toBe(true);
    expect(menuItems.length).toBe(12);
  });

  test("each menu item should have required properties", () => {
    menuItems.forEach(item => {
      expect(item).toHaveProperty("id");
      expect(item).toHaveProperty("category");
      expect(item).toHaveProperty("name");
      expect(item).toHaveProperty("description");
      expect(item).toHaveProperty("price");
      expect(item).toHaveProperty("image");
    });
  });

  test("should have valid category names for known groups", () => {
    const validCategories = ["pizzas", "hot meals", "drinks", "desserts"];
    menuItems.forEach(item => {
      expect(validCategories).toContain(item.category);
    });
  });

  test("should have a price greater than 0 for each item", () => {
    menuItems.forEach(item => {
      expect(item.price).toBeGreaterThan(0);
    });
  });
});
