import React from "react";
import { render, screen } from "@testing-library/react";
import MenuItem from "../Components/MenuItem";

describe("MenuItem Component", () => {
  const dummyItem = {
    image: "dummy.jpg",
    name: "Test Item",
    description: "This is a test description.",
    price: 12.345, // Expect formatted as "$12.35"
  };

  beforeEach(() => {
    render(<MenuItem item={dummyItem} />);
  });

  test("renders an image with correct src and alt attributes", () => {
    const image = screen.getByRole("img");
    expect(image).toBeInTheDocument();
    expect(image).toHaveAttribute("src", dummyItem.image);
    expect(image).toHaveAttribute("alt", dummyItem.name);
  });

  test("displays the correct item name", () => {
    expect(screen.getByRole("heading", { level: 3 })).toHaveTextContent(dummyItem.name);
  });

  test("displays the correct item description", () => {
    expect(screen.getByText(dummyItem.description)).toBeInTheDocument();
  });

  test("formats and displays the price correctly", () => {
    // Price formatted to two decimals
    const formattedPrice = `$${dummyItem.price.toFixed(2)}`;
    expect(screen.getByText(formattedPrice)).toBeInTheDocument();
  });

  test("renders the Add button", () => {
    expect(screen.getByRole("button", { name: /add/i })).toBeInTheDocument();
  });
});
