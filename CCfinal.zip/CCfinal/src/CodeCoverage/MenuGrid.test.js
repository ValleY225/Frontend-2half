import React from "react";
import { render, screen } from "@testing-library/react";
import MenuGrid from "../Components/MenuGrid";
import menuItems from "../Components/Data";

// Mock the MenuItem component so that it displays the item name.
jest.mock("../Components/MenuItem", () => ({ item }) => {
  return <div data-testid="menu-item">{item.name}</div>;
});

describe("MenuGrid Component", () => {
  beforeEach(() => {
    render(<MenuGrid />);
  });

  test("renders a section for each unique category", () => {
    // Calculate unique categories from the data
    const uniqueCategories = [...new Set(menuItems.map((item) => item.category))];
    uniqueCategories.forEach((category) => {
      // Capitalize the category as rendered (first letter uppercase)
      const renderedCategory = category.charAt(0).toUpperCase() + category.slice(1);
      expect(screen.getByText(renderedCategory)).toBeInTheDocument();
    });
  });

  test("renders all menu items in their respective categories", () => {
    // Count all MenuItem renders by their test id
    const renderedItems = screen.getAllByTestId("menu-item");
    expect(renderedItems).toHaveLength(menuItems.length);
  });
});
