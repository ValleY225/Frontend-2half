import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import ReservationForm from "../Components/ReservationForm";

describe("ReservationForm Component", () => {
  let container;
  const onCloseMock = jest.fn();

  beforeEach(() => {
    // Render the component and store the container for querying non-accessible inputs
    const renderResult = render(<ReservationForm onClose={onCloseMock} />);
    container = renderResult.container;
    onCloseMock.mockClear();
    // Spy on the window.alert so that we can check its call without showing a real alert
    jest.spyOn(window, "alert").mockImplementation(() => {});
  });

  afterEach(() => {
    // Restore the original alert after each test to avoid side effects
    window.alert.mockRestore();
  });

  test("renders all inputs and buttons", () => {
    // Check for the name input using its placeholder text
    expect(screen.getByPlaceholderText(/your name/i)).toBeInTheDocument();

    // For date, time, and number inputs, use the container to query by input type
    const dateInput = container.querySelector('input[type="date"]');
    const timeInput = container.querySelector('input[type="time"]');
    const guestsInput = container.querySelector('input[type="number"]');
    expect(dateInput).toBeInTheDocument();
    expect(timeInput).toBeInTheDocument();
    expect(guestsInput).toBeInTheDocument();

    // Check that both "Reserve" and "Cancel" buttons are rendered
    expect(screen.getByRole("button", { name: /reserve/i })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /cancel/i })).toBeInTheDocument();
  });

  test("submits form with valid data, triggers alert and calls onClose", () => {
    const nameInput = screen.getByPlaceholderText("Your Name");
    const dateInput = container.querySelector('input[type="date"]');
    const timeInput = container.querySelector('input[type="time"]');
    const guestsInput = container.querySelector('input[type="number"]');

    // Simulate user filling the form
    fireEvent.change(nameInput, { target: { value: "John Doe" } });
    fireEvent.change(dateInput, { target: { value: "2025-05-10" } });
    fireEvent.change(timeInput, { target: { value: "18:00" } });
    fireEvent.change(guestsInput, { target: { value: "4" } });

    // Find the form element and submit it
    const form = container.querySelector("form");
    fireEvent.submit(form);

    // Check that alert was called with the expected reservation message
    expect(window.alert).toHaveBeenCalledWith(
      "Reservation for John Doe on 2025-05-10 at 18:00 for 4 guests."
    );
    // Verify that onClose callback was called after submission
    expect(onCloseMock).toHaveBeenCalled();
  });

  test("clicking cancel button calls onClose", () => {
    const cancelButton = screen.getByRole("button", { name: /cancel/i });
    fireEvent.click(cancelButton);
    expect(onCloseMock).toHaveBeenCalled();
  });
});
