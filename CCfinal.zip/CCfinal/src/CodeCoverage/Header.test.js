import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import Header from "../Components/Header";

// Mock Modal and its content
jest.mock("../Components/Modal", () => ({ children, isOpen, onClose }) =>
  isOpen ? (
    <div data-testid="modal">
      {children}
      <button onClick={onClose}>Close Modal</button>
    </div>
  ) : null
);

// Mock DeliveryForm
jest.mock("../Components/DeliveryForm", () => ({ onClose }) => (
  <div data-testid="delivery-form">
    DeliveryForm
    <button onClick={onClose}>Close Delivery</button>
  </div>
));

// Mock ReservationForm
jest.mock("../Components/ReservationForm", () => ({ onClose }) => (
  <div data-testid="reservation-form">
    ReservationForm
    <button onClick={onClose}>Close Reservation</button>
  </div>
));

describe("Header Component", () => {
  beforeEach(() => {
    render(<Header />);
  });

  test("renders delivery and reservation buttons", () => {
    expect(screen.getByText(/order delivery/i)).toBeInTheDocument();
    expect(screen.getByText(/reserve table/i)).toBeInTheDocument();
  });

  test("shows delivery modal when 'Order Delivery' is clicked", () => {
    fireEvent.click(screen.getByText(/order delivery/i));
    expect(screen.getByTestId("delivery-form")).toBeInTheDocument();
    fireEvent.click(screen.getByText(/close delivery/i));
    expect(screen.queryByTestId("delivery-form")).not.toBeInTheDocument();
  });

  test("shows reservation modal when 'Reserve Table' is clicked", () => {
    fireEvent.click(screen.getByText(/reserve table/i));
    expect(screen.getByTestId("reservation-form")).toBeInTheDocument();
    fireEvent.click(screen.getByText(/close reservation/i));
    expect(screen.queryByTestId("reservation-form")).not.toBeInTheDocument();
  });
});
