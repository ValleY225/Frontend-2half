import React from "react";
import "../Style/Navbar.css";

const Navbar = () => {
  const handleClick = (sectionId, e) => {
    e.target.blur(); // Remove focus after click
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav className="Navbar">
      <ul className="nav-categories">
        <li>
          <button className="nav-btn" onClick={(e) => handleClick("pizzas", e)}>
            Pizzas
          </button>
        </li>
        <li>
          <button className="nav-btn" onClick={(e) => handleClick("hot-meals", e)}>
            Hot Meals
          </button>
        </li>
        <li>
          <button className="nav-btn" onClick={(e) => handleClick("drinks", e)}>
            Drinks
          </button>
        </li>
        <li>
          <button className="nav-btn" onClick={(e) => handleClick("desserts", e)}>
            Desserts
          </button>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
