// Pizzas
import Mar from "../Photos/Mar.jpg";
import Pep from "../Photos/Pep.jpg";
import Veg from "../Photos/veg.jpg";

// Hot Meals
import Hot1 from "../Photos/Hot1.jpg";
import Hot2 from "../Photos/Hot2.jpg";
import Hot3 from "../Photos/Hot3.jpg";

// Drinks
import Drink1 from "../Photos/Drink1.jpg";
import Drink2 from "../Photos/Drink2.jpg";
import Drink3 from "../Photos/Drink3.jpg";

// Desserts
import Dessert1 from "../Photos/Dessert1.jpg";
import Dessert2 from "../Photos/Dessert2.jpg";
import Dessert3 from "../Photos/Dessert3.jpg";

const menuItems = [
  // Pizzas
  {
    id: 1,
    category: "pizzas",
    name: "Margherita Pizza",
    description: "Classic delight with fresh tomatoes, basil, and mozzarella cheese.",
    price: 9.99,
    image: Mar,
  },
  {
    id: 2,
    category: "pizzas",
    name: "Pepperoni Pizza",
    description: "Loaded with pepperoni and extra cheese for a spicy kick.",
    price: 12.99,
    image: Pep,
  },
  {
    id: 3,
    category: "pizzas",
    name: "Veggie Delight",
    description: "A mix of fresh vegetables, herbs, and a light tomato sauce.",
    price: 10.99,
    image: Veg,
  },

  // Hot Meals
  {
    id: 4,
    category: "hot meals",
    name: "Grilled Chicken",
    description: "Juicy grilled chicken served with steamed vegetables.",
    price: 14.99,
    image: Hot1,
  },
  {
    id: 5,
    category: "hot meals",
    name: "Beef Burger",
    description: "Classic beef burger with lettuce, tomato, and a special sauce.",
    price: 11.99,
    image: Hot2,
  },
  {
    id: 6,
    category: "hot meals",
    name: "Fish & Chips",
    description: "Crispy battered fish served with golden fries and tartar sauce.",
    price: 13.99,
    image: Hot3,
  },

  // Drinks
  {
    id: 7,
    category: "drinks",
    name: "Lemonade",
    description: "Freshly squeezed lemonade with a hint of mint.",
    price: 3.99,
    image: Drink1,
  },
  {
    id: 8,
    category: "drinks",
    name: "Iced Tea",
    description: "Chilled iced tea brewed with aromatic herbs.",
    price: 3.49,
    image: Drink2,
  },
  {
    id: 9,
    category: "drinks",
    name: "Smoothie",
    description: "A blend of seasonal fruits for a refreshing taste.",
    price: 4.99,
    image: Drink3,
  },

  // Desserts
  {
    id: 10,
    category: "desserts",
    name: "Chocolate Cake",
    description: "Rich and moist chocolate cake topped with ganache.",
    price: 5.99,
    image: Dessert1,
  },
  {
    id: 11,
    category: "desserts",
    name: "Ice Cream Sundae",
    description: "Classic sundae with vanilla ice cream, chocolate syrup, and nuts.",
    price: 4.99,
    image: Dessert2,
  },
  {
    id: 12,
    category: "desserts",
    name: "Apple Pie",
    description: "Traditional apple pie with a flaky crust and a cinnamon-spiced filling.",
    price: 4.49,
    image: Dessert3,
  },
];

export default menuItems;
