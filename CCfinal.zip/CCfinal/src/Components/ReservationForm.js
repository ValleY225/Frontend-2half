import React, { useState } from "react";
import "../Style/Form.css";

const ReservationForm = ({ onClose }) => {
  const [name, setName] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [guests, setGuests] = useState(1);

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Reservation for ${name} on ${date} at ${time} for ${guests} guests.`);
    onClose();
  };

  return (
    <div className="form-container">
      <h2>Table Reservation</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Your Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          required
        />
        <input
          type="time"
          value={time}
          onChange={(e) => setTime(e.target.value)}
          required
        />
        <input
          type="number"
          min="1"
          max="20"
          value={guests}
          onChange={(e) => setGuests(e.target.value)}
          required
        />
        <button type="submit">Reserve</button>
        <button type="button" onClick={onClose}>
          Cancel
        </button>
      </form>
    </div>
  );
};

export default ReservationForm;
