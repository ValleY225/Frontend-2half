import React from "react";
import "../Style/Container.css";
import Header from "./Header";
import MenuGrid from "./MenuGrid";
import Navbar from "./Navbar";

function App() {
  return (
    <div className="container">
      <Header />
      <MenuGrid />
      <Navbar />
    </div>
  );
}

export default App;
