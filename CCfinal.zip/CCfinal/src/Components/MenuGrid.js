import React from "react"; 
import menuItems from "./Data";
import MenuItem from "./MenuItem";
import "../Style/MenuGrid.css";

const MenuGrid = () => {
  const categories = [...new Set(menuItems.map((item) => item.category))];

  return (
    <section className="menu-grid">
      {categories.map((category) => (
        <div key={category} id={category} className="menu-category">
          <h2>{category.charAt(0).toUpperCase() + category.slice(1)}</h2>
          {/* New container for menu items */}
          <div className="menu-items">
            {menuItems
              .filter((item) => item.category === category)
              .map((item) => (
                <MenuItem key={item.id} item={item} />
              ))}
          </div>
        </div>
      ))}
    </section>
  );
};

export default MenuGrid;
