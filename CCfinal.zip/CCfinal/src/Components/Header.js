import React, { useState } from "react";
import "../Style/Header.css";
import Modal from "./Modal";
import DeliveryForm from "./DeliveryForm";
import ReservationForm from "./ReservationForm";

const Header = () => {
  const [showDelivery, setShowDelivery] = useState(false);
  const [showReservation, setShowReservation] = useState(false);

  return (
    <header className="Header">
      <nav className="nav-buttons">
        <button className="primary-btn" onClick={() => setShowDelivery(true)}>
          Order Delivery
        </button>
        <button className="primary-btn" onClick={() => setShowReservation(true)}>
          Reserve Table
        </button>
      </nav>

      <Modal isOpen={showDelivery} onClose={() => setShowDelivery(false)}>
        <DeliveryForm onClose={() => setShowDelivery(false)} />
      </Modal>

      <Modal isOpen={showReservation} onClose={() => setShowReservation(false)}>
        <ReservationForm onClose={() => setShowReservation(false)} />
      </Modal>
    </header>
  );
};

export default Header;
