import fs from "fs";
import path from "path";
import express from "express";
import React from "react";
import ReactDOMServer from "react-dom/server";
import { Menu } from "./src/Menu.js";

const PORT = process.env.PORT || 4000;
const app = express();

app.use("^/$", (req, res) => {
  const appHtml = ReactDOMServer.renderToString(<Menu />);

  const indexFile = path.resolve("./build/index.html");
  fs.readFile(indexFile, "utf8", (err, data) => {
    if (err) {
      console.error("Error reading HTML file", err);
      return res.status(500).send("An error occurred");
    }

    return res.send(
      data.replace('<div id="root"></div>', `<div id="root">${appHtml}</div>`)
    );
  });
});

app.listen(PORT, () =>
  console.log(`Server is listening on port ${PORT}`)
);
